package com.example.meteomars.Service;

public interface Callback<T> {
    void onResponse(T t);

}
