package com.example.meteomars.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.meteomars.Model.Sol;
import com.example.meteomars.R;
import com.example.meteomars.Service.NasaService;
import com.example.meteomars.View.WindRoseView;

import org.w3c.dom.Text;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class DetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        DecimalFormat df = new DecimalFormat("##.##");
        df.setRoundingMode(RoundingMode.DOWN);

        Sol sol_click= (Sol) getIntent().getSerializableExtra("sol");
        Toast.makeText(this, "Sol n° " + sol_click.getNumero(), Toast.LENGTH_SHORT).show();

        TextView solName = findViewById(R.id.sol_name_detail);
        TextView solTemp = findViewById(R.id.temp_sol_detail);
        TextView solPres = findViewById(R.id.pressure_sol_detail);
        WindRoseView windRoseView = findViewById(R.id.roseView);

        String avTemp = df.format(sol_click.getAverageTemp());
        String maxTemp = df.format(sol_click.getMaxTemp());
        String minTemp = df.format(sol_click.getMinTemp());

        String avPres = df.format(sol_click.getAveragePres());
        String maxPres = df.format(sol_click.getMaxPres());
        String minPres = df.format(sol_click.getMinPres());


        String solPrefix = getResources().getString(R.string.sol_prefix);

        windRoseView.setSol(sol_click);
        solName.setText(solPrefix + sol_click.getNumero());
        solTemp.setText(String.format("Température (°C) :\nAv : %s   Min : %s    Max : %s", avTemp, minTemp, maxTemp));
        solPres.setText(String.format("Pression (Pa) :\nAv : %s   Min : %s    Max : %s", avPres, minPres, maxPres));
    }
}
