package com.example.meteomars.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.meteomars.Model.Sol;
import com.example.meteomars.R;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;

public class SolAdapter extends ArrayAdapter {
    private Context context;
    private List<Sol> values;
    private LayoutInflater inflater;

    public SolAdapter(Context context, List<Sol> solList){
        super(context, -1, solList);
        this.context = context;
        this.values = solList;
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View rowView = inflater.inflate(R.layout.row_layout, parent, false);
        DecimalFormat df = new DecimalFormat("##.##");
        df.setRoundingMode(RoundingMode.DOWN);

        Sol model = values.get(position);

        TextView numero = rowView.findViewById(R.id.nom_sol);
        TextView temperature = rowView.findViewById(R.id.temperature_sol);
        TextView pression = rowView.findViewById(R.id.pression_sol);


        numero.setText(model.getNumero());
        String solPrefix = context.getResources().getString(R.string.sol_prefix);
        String tempPrefix = context.getResources().getString(R.string.temperature_prefix);
        String presPrefix = context.getResources().getString(R.string.pression_prefix);
        numero.setText(solPrefix + model.getNumero());
        temperature.setText(tempPrefix + df.format(model.getAverageTemp()));
        pression.setText(presPrefix + df.format(model.getAveragePres()));


        return rowView;

    }
}
