package com.example.meteomars.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.meteomars.Adapter.SolAdapter;
import com.example.meteomars.Model.Sol;
import com.example.meteomars.R;
import com.example.meteomars.Service.NasaService;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        NasaService nasaService = NasaService.getInstance(getApplicationContext());
        nasaService.getMeteo(this);



    }

    public void showSol(final List<Sol> solList){
        Toast.makeText(getApplicationContext(), "NB Sol : " + solList.size(), Toast.LENGTH_SHORT).show();
        ListView listView = findViewById(R.id.list_sol);
        SolAdapter adapter = new SolAdapter(getApplicationContext(), solList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                Sol sol_click = solList.get(position);
                intent.putExtra("sol", sol_click);
                startActivity(intent);
            }
        });


    }
}
