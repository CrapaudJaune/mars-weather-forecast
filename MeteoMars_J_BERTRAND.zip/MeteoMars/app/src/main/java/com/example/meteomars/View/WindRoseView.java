package com.example.meteomars.View;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import java.lang.Math;

import androidx.annotation.Nullable;

import com.example.meteomars.Model.Sol;
import com.example.meteomars.R;

import java.util.ArrayList;
import java.util.Collections;

import static java.util.Collections.max;

public class WindRoseView extends View {
    private Paint roseCirclePaint;
    private Paint cardinalTracePaint;
    private Paint trianglePaint;

    private Sol sol;
    private final float tan_x = (float) Math.tan(Math.PI/16);

    public WindRoseView(Context context) {
        super(context);
        init();
    }

    public WindRoseView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WindRoseView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {

        this.roseCirclePaint = new Paint();
        this.roseCirclePaint.setStyle(Paint.Style.FILL);
        this.roseCirclePaint.setColor(getResources().getColor(R.color.windRoseColor));

        this.cardinalTracePaint = new Paint();
        this.cardinalTracePaint.setStyle(Paint.Style.STROKE);
        this.cardinalTracePaint.setStrokeWidth(5);
        this.cardinalTracePaint.setColor(getResources().getColor(R.color.colorPrimaryDark));

        this.trianglePaint = new Paint();
        this.trianglePaint.setStyle(Paint.Style.FILL);
        this.trianglePaint.setColor(getResources().getColor(R.color.colorAccent));

    }

    public void setSol(Sol sol) {
        this.sol = sol;
        this.invalidate();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        canvas.translate(width / 2, height / 2);
        //La rose
        canvas.drawCircle(0, 0, width/2, roseCirclePaint);
        canvas.drawCircle(0, 0, width/2, cardinalTracePaint);

        //Les points cardinaux
        canvas.drawLine(-width, 0, width, 0, cardinalTracePaint);
        canvas.drawLine(0,-width,0, width, cardinalTracePaint);

        ArrayList <Integer> windForce = sol.getWindForceArray();
        int windMax = Collections.max(windForce);
        //int indexMax = windForce.indexOf(windMax);
        float rapport = (float) (width/2)/windMax;
        for (int i : windForce){
            float y = (float) i*rapport;
            float x = tan_x * y; //je divise par 2 pour décoller les triangles les uns des autres, car j'avais un soucis de superposition
            Path path = new Path();
            path.lineTo(-x/2, -y);
            path.lineTo(x/2,-y);
            path.lineTo(0,0);
            path.close();
            canvas.drawPath(path, trianglePaint);
            canvas.drawPath(path, cardinalTracePaint);
            canvas.rotate((float) 22.5);
        }




    }
}