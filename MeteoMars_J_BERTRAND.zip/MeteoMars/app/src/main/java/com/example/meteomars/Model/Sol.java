package com.example.meteomars.Model;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Sol implements Serializable {
    private String numero;
    private String saison;
    private double averageTemp;
    private double maxTemp;
    private double minTemp;
    private double averagePres;
    private double maxPres;
    private double minPres;
    private ArrayList<Integer> windForceArray = new ArrayList<>();

    public double getAverageTemp() {
        return averageTemp;
    }

    public double getMaxTemp() {
        return maxTemp;
    }


    public double getMinTemp() {
        return minTemp;
    }


    public double getAveragePres() {
        return averagePres;
    }


    public ArrayList<Integer> getWindForceArray() {
        return windForceArray;
    }

    public double getMaxPres() {
        return maxPres;
    }


    public double getMinPres() {
        return minPres;
    }


    public String getNumero() {
        return numero;
    }


    public String getSaison() {
        return saison;
    }


    public Sol (JSONObject jsonObject, String numero){
        fromJsonObject(jsonObject, numero);
    }

    public void fromJsonObject(JSONObject jsonObject, String numero){
        try {
            String season =
                    jsonObject.getString("Season");
            this.saison = season;
            JSONObject temperatures =
                    jsonObject.getJSONObject("AT");
            this.averageTemp = temperatures.getDouble("av");
            this.maxTemp = temperatures.getDouble("mx");
            this.minTemp = temperatures.getDouble("mn");
            JSONObject pressures =
                    jsonObject.getJSONObject("PRE");
            this.averagePres = pressures.getDouble("av");
            this.maxPres = pressures.getDouble("mx");
            this.minPres = pressures.getDouble("mn");
            this.numero = numero;
            JSONObject windData =
                    jsonObject.getJSONObject("WD");
            for (int i = 0; i<16; i++){
                String iToString = String.valueOf(i);
                if(windData.has(iToString)) {
                    JSONObject windI =
                            windData.getJSONObject(iToString);
                    Integer windForceI = windI.getInt("ct");
                    windForceArray.add(windForceI);
                }
                else {
                    windForceArray.add(0);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
