package com.example.meteomars.Service;


import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.meteomars.Activity.HomeActivity;
import com.example.meteomars.Model.Sol;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NasaService {
    private String API_KEY = "LlqCtPh4zl8oKOW13PR3Ucs9gQ7N4TbUEPkwf71D";
    private static NasaService instance;
    private RequestQueue requestQueue;
    private Context context;

    private NasaService(Context context){
        this.context = context;
        this.requestQueue = Volley.newRequestQueue(context); 
    }
    
    public static NasaService getInstance(Context context){
        if (instance == null){
            instance = new NasaService(context);
        }
        return instance;
    }

    public void getMeteo(final HomeActivity homeActivity){
        String url = String.format("https://api.nasa.gov/insight_weather/?api_key=%s&feedtype=json&ver=1.0",API_KEY);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(context,"DATA RECEIVED", Toast.LENGTH_SHORT).show();
                        List<Sol> results = new ArrayList<>();
                        try {
                            JSONArray solKeys =
                                    response.getJSONArray("sol_keys");
                            for (int i = 0; i<solKeys.length();i++){
                                JSONObject thatSol =
                                        response.getJSONObject(solKeys.getString(i));
                                results.add(new Sol(thatSol, solKeys.getString(i)));
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        homeActivity.showSol(results);
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

        );
        requestQueue.add(jsonObjectRequest);
    }
}


